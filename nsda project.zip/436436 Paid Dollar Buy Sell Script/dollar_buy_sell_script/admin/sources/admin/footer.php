		</div>
      </div>
      <footer class="templatemo-footer">
        <div class="templatemo-copyright">
          <p>Copyright &copy; 2020 by DoridroTech</p>
        </div>
      </footer>
    </div>

    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="assets/cleditor/jquery.cleditor.css" />
    <script type="text/javascript" src="assets/cleditor/jquery.cleditor.min.js"></script>
    <script>
        $(document).ready(function () { $(".cleditor").cleditor(); });
    </script>
</body>
</html>