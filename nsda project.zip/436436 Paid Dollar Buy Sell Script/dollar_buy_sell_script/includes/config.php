<?php
	$CONF = array();
	$CONF["host"] = "localhost";
	$CONF["user"] = "root";
	$CONF["pass"] = "";
	$CONF["name"] = "test";
	?>