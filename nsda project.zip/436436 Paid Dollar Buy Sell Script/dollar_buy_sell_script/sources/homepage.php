 	<!-- main -->
	<section id="main" class="clearfix home-default">
		<div class="container">
			<span class="btn btn" style="text-align: center; font-weight: 600; font-size: 18px; background:#000094; color: white; width: 100%; height:40px;">
<marquee behavior="scroll" direction="center" onmouseover="this.stop();" onmouseout="this.start();" id="MARQUEE1" style="text-align: left;" class="scrolling">  
<span style="color: yellow"><strong>নোটিশ:</strong></span>  Skrill &amp; Neteller মিনিমাম 10$ Order করবেন।  আর সবসময় Round Figer Amount order করবেন যেমন: 10$/15$/20$/25$ বা 30$ এমন এবং ডলারের রেট এর সাথে 60 টাকা Extra পাঠাবেন। সার্ভিস টাইম প্রতিদিন সকাল 9:00 AM থেকে রাত 11:00 PM পর্যন্ত। </marquee></span>

			<!-- main-content -->
			<div class="main-content">
				<!-- row -->
				<div class="row">
					<!-- product-list -->
					<div class="col-md-9">
						<!-- categorys -->
						<div style="background: linear-gradient(#5aba00, #f6f1d3);" class="section">
						    <h1 class="home_h1 text-center">START EXCHANGE</h1>	
							<div class="row" id="bit_exchange_box">
					<div id="bit_exchange_results"></div>
								<form id="bit_exchange_form">
								<div class="col-md-6">
									<div class="row">
										<div class="col-md-3 hidden-xs hidden-sm">
											<div style="margin-top:50px;">
												<img src="assets/icons/Bitcoin.png" id="bit_image_send" width="72px" height="72px" class="img-circle img-bordered">
											</div>
										</div>
										<div class="col-md-9">
											<h3><i class="fa fa-arrow-down"></i> <?php echo $lang['send']; ?> (আপনি পাঠাবেন)</h3>
											<div class="form-group">
												<select class="form-control form_style_1 input-lg" id="bit_gateway_send" name="bit_gateway_send" onchange="bit_refresh('1');">
													<?php
													$gateways = $db->query("SELECT * FROM bit_gateways WHERE allow_send='1' and status='1' ORDER BY id");
													if($gateways->num_rows>0) {
														while($g = $gateways->fetch_assoc()) {
															if($g['default_send'] == "1") { $sel = 'selected'; } else { $sel = ''; }
															echo '<option value="'.$g[id].'" '.$sel.'>'.$g[name].' '.$g[currency].'</option>';
														}
													} else {
														echo '<option>'.$lang[no_have_gateways].'</option>';
													}
													?>
												</select>
											</div>
											<div class="form-group">
												<input type="text" class="form-control form_style_1 input-lg" id="bit_amount_send" name="bit_amount_send" value="0" onkeyup="bit_calculator();" onkeydown="bit_calculator();">
											</div>
											<div class="text text-muted pull-right" style="padding-bottom:10px;font-weight:bold;"><?php echo $lang['exchange_rate']; ?>: <span id="bit_exchange_rate">-</span></div>
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<div class="row">
										<div class="col-md-9">
											<h3><i class="fa fa-arrow-up"></i> <?php echo $lang['receive']; ?> (আপনি পাবেন)</h3>
											<div class="form-group">
												<select class="form-control form_style_1 input-lg" id="bit_gateway_receive" name="bit_gateway_receive"  onchange="bit_refresh('2');">
													<?php
											$gateways = $db->query("SELECT * FROM bit_gateways WHERE allow_receive='1' and status='1' ORDER BY id");
											if($gateways->num_rows>0) {
												while($g = $gateways->fetch_assoc()) {
													if($g['default_receive'] == "1") { $sel = 'selected'; } else { $sel = ''; }
													echo '<option value="'.$g[id].'" '.$sel.'>'.$g[name].' '.$g[currency].'</option>';
												}
											} else {
												echo '<option>'.$lang[no_have_gateways].'</option>';
											}
											?>
												</select>
											</div>
											<div class="form-group">
												<input type="text" class="form-control form_style_1 input-lg" id="bit_amount_receive" name="bit_amount_receive" disabled value="0">
											</div>
											<div class="text text-muted" style="padding-bottom:10px;font-weight:bold;"><?php echo $lang['reserve']; ?>: <span id="bit_reserve">-</span></div>
										</div>
										<div class="col-md-3 hidden-xs hidden-sm">
											<div style="margin-top:50px;">
												<img src="assets/icons/Skrill.png" id="bit_image_receive" width="72px" height="72px" class="img-circle img-bordered">
											</div>
										</div>
									</div>
								</div>
								<div class="col-md-12">
									<input type="hidden" name="bit_amount_receive" id="bit_amount_receive2">
									<input type="hidden" name="bit_rate_from" id="bit_rate_from">
									<input type="hidden" name="bit_rate_to" id="bit_rate_to">
									<input type="hidden" name="bit_currency_from" id="bit_currency_from">
									<input type="hidden" name="bit_currency_to" id="bit_currency_to">
									<input type="hidden" id="bit_login_to_exchange" name="bit_login_to_exchange" value="<?php echo $settings['login_to_exchange']; ?>">
									<input type="hidden" id="bit_ses_uid" name="bit_ses_uid" value="<?php if(checkSession()) { echo $_SESSION['bit_uid']; } else { echo '0'; } ?>">
									<center>
										<button type="button" style="background: #000094;" class="btn btn-primary btn-lg"  onclick="bit_exchange_step_1();">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-refresh"></i> <?php echo $lang['btn_exchange']; ?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</button>
									</center>
									<div class="pull-center" style="text-align: right;font-size: 16px;color: #FFFFFF;font-style: normal;"> <a style="color:red" href="/page/about">Our Rules</a></div>
								</div>
							</form>			
							</div>
						</div><!-- category-ad -->	
						
						<!-- featureds -->
						
						
						
						
						
						
						
					<!-- trending-ads -->
					<div class="section trending-ads">
						
							
							
							

							<div class="row" style="
    overflow: scroll;
">
								<div class="col-md-12">
									<table bordercolor="#3b6a9e" border="1" class="table">
									    <caption class="text-center"><h4 style="
    font-weight: bold;
    font-size: 27px;
    border-bottom: 1px solid;
    padding-bottom: 9px;
    color: #000;
"><img src="/assets/img/full.gif" width="" height="25">Pending Exchanges<img src="/assets/img/full.gif" width="" height="25">

</h4></caption>
									    
									    
										<thead>
											<tr>
											    
											    <th>Username</th>
												<th><?php echo $lang['send']; ?></th>
												<th><?php echo $lang['receive']; ?></th>
												<th><?php echo $lang['amount']; ?></th>
											
												<th><?php echo $lang['status']; ?></th>
												
										<th>Date & Time</th>		
												
												
											</tr>
										</thead>
										<tbody class="tbodybgcolor">
											<?php
											$query = $db->query("SELECT * FROM bit_exchanges ORDER BY id DESC LIMIT 10"); 
											if($query->num_rows>0) {
												while($row = $query->fetch_assoc()) {
													?>
													
													
												<?php
										if($row['status'] == "2" || $row['status'] == "3" || $row['status'] == "1" || $row['status'] == "5" || $row['status'] == "6") { ?>
													
													
													
													<tr>
													    
													    <td>
															<span class="label label-default"><i class="fa fa-user-o"></i>  <?php echo idinfo($row['uid'],"username"); ?></span>															
														</td>
													    
													    
														<td>
														    
									      
														    
														    <img src="<?php echo gatewayicon(gatewayinfo($row['gateway_send'],"name")); ?>" width="20px" height="20"> <?php echo gatewayinfo($row['gateway_send'],"name"); ?> <?php echo gatewayinfo($row['gateway_send'],"currency"); ?></td>
														<td><img src="<?php echo gatewayicon(gatewayinfo($row['gateway_receive'],"name")); ?>" width="20px" height="20"> <?php echo gatewayinfo($row['gateway_receive'],"name"); ?> <?php echo gatewayinfo($row['gateway_receive'],"currency"); ?></td>
														<td><?php echo $row['amount_send']; ?> <?php echo gatewayinfo($row['gateway_send'],"currency"); ?></td>
												
														<td><?php
										if($row['status'] == "1") {
											echo '<span class="label label-warning"><i class="fa fa-clock-o"></i> '.$lang[status_1].'</span>';
										} elseif($row['status'] == "2") {
											echo '<span class="label label-warning"><i class="fa fa-clock-o"></i> '.$lang[status_2].'</span>';
										} elseif($row['status'] == "3") {
											echo '<span class="label label-info"><i class="fa fa-clock-o"></i> '.$lang[status_3].'</span>';
										} elseif($row['status'] == "4") {
											echo '<span class="label label-success"><i class="fa fa-check"></i> '.$lang[status_4].'</span>';
										} elseif($row['status'] == "5") {
											echo '<span class="label label-danger"><i class="fa fa-times"></i> '.$lang[status_5].'</span>';
										} elseif($row['status'] == "6") {
											echo '<span class="label label-danger"><i class="fa fa-times"></i> '.$lang[status_6].'</span>';
										} elseif($row['status'] == "7") {
											echo '<span class="label label-danger"><i class="fa fa-times"></i> '.$lang[status_7].'</span>';
										} else {
											echo '<span class="label label-default">'.$lang[status_unknown].'</span>';
										}
										?></td>
										
									
										
										
										
										<td>					    
														 	<?php
										if($row['created']) {
											echo ''.date("d/m/Y h:i:sa",$row[created]).'';
										
										    
										} else {
											echo '-';
										}
										?> </td>
										
										
													</tr>
													
																										<?php 	}
											?>


													
													
													<?php
												}
											} else {
												echo '<tr><td colspan="5">'.$lang[still_no_exchanges].'</td></tr>';
											}
											?>

											
										</tbody>
									</table>
								</div>
							</div>
							
							
							
							
							
							
							
							
						</div>
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
		
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
							
					<!-- trending-ads -->
					<div class="section trending-ads">
						
							
							
						

							<div class="row" style="
    overflow: scroll;
">
								<div class="col-md-12">
									<table bordercolor="#3b6a9e" border="1" class="table">
									    <caption class="text-center"><h4 style="
    font-weight: bold;
    font-size: 27px;
    border-bottom: 1px solid;
    padding-bottom: 9px;
    color: #000;
"><img src="/assets/img/full.gif" width="" height="25">Completed Exchanges<img src="/assets/img/full.gif" width="" height="25">

</h4></caption>
									    
									    
										<thead>
											<tr>
											    
											    <th>Username</th>
												<th><?php echo $lang['send']; ?></th>
												<th><?php echo $lang['receive']; ?></th>
												<th><?php echo $lang['amount']; ?></th>
											
												<th><?php echo $lang['status']; ?></th>
												
										<th>Date & Time</th>		
												
												
											</tr>
										</thead>
										<tbody class="tbodybgcolor">
											<?php
											$query = $db->query("SELECT * FROM bit_exchanges ORDER BY id DESC LIMIT 10"); 
											if($query->num_rows>0) {
												while($row = $query->fetch_assoc()) {
													?>
													
													
												<?php
										if($row['status'] == "4") { ?>
													
													
													
													<tr>
													    
													    <td>
															<span class="label label-default"><i class="fa fa-user-o"></i>  <?php echo idinfo($row['uid'],"username"); ?></span>															
														</td>
													    
													    
														<td>
														    
									      
														    
														    <img src="<?php echo gatewayicon(gatewayinfo($row['gateway_send'],"name")); ?>" width="20px" height="20"> <?php echo gatewayinfo($row['gateway_send'],"name"); ?> <?php echo gatewayinfo($row['gateway_send'],"currency"); ?></td>
														<td><img src="<?php echo gatewayicon(gatewayinfo($row['gateway_receive'],"name")); ?>" width="20px" height="20"> <?php echo gatewayinfo($row['gateway_receive'],"name"); ?> <?php echo gatewayinfo($row['gateway_receive'],"currency"); ?></td>
														<td><?php echo $row['amount_send']; ?> <?php echo gatewayinfo($row['gateway_send'],"currency"); ?></td>
												
														<td><?php
										if($row['status'] == "1") {
											echo '<span class="label label-warning"><i class="fa fa-clock-o"></i> '.$lang[status_1].'</span>';
										} elseif($row['status'] == "2") {
											echo '<span class="label label-warning"><i class="fa fa-clock-o"></i> '.$lang[status_2].'</span>';
										} elseif($row['status'] == "3") {
											echo '<span class="label label-info"><i class="fa fa-clock-o"></i> '.$lang[status_3].'</span>';
										} elseif($row['status'] == "4") {
											echo '<span class="label label-success"><i class="fa fa-check"></i> '.$lang[status_4].'</span>';
										} elseif($row['status'] == "5") {
											echo '<span class="label label-danger"><i class="fa fa-times"></i> '.$lang[status_5].'</span>';
										} elseif($row['status'] == "6") {
											echo '<span class="label label-danger"><i class="fa fa-times"></i> '.$lang[status_6].'</span>';
										} elseif($row['status'] == "7") {
											echo '<span class="label label-danger"><i class="fa fa-times"></i> '.$lang[status_7].'</span>';
										} else {
											echo '<span class="label label-default">'.$lang[status_unknown].'</span>';
										}
										?></td>
										
									
										
										
										
										<td>					    
														 	<?php
										if($row['created']) {
											echo ''.date("d/m/Y h:i:sa",$row[created]).'';
										
										    
										} else {
											echo '-';
										}
										?> </td>
										
										
													</tr>
													
																										<?php 	}
											?>


													
													
													<?php
												}
											} else {
												echo '<tr><td colspan="5">'.$lang[still_no_exchanges].'</td></tr>';
											}
											?>

											
										</tbody>
									</table>
								</div>
							</div>
							
							
							
							
							
							
							
							
						</div>
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
		
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						
						<!-- this site design by DoridroTech.Com -->
						
					<!-- trending-ads -->
					<div class="section trending-ads">
						
							
							
						

							<div class="row" style="
    overflow: scroll;
">
								<div class="col-md-12">
									<table bordercolor="#3b6a9e" border="1" class="table">
									    <caption class="text-center"><h4 style="
    font-weight: bold;
    font-size: 27px;
    border-bottom: 1px solid;
    padding-bottom: 9px;
    color: #000;
"><img src="/assets/img/full.gif" width="" height="25">Cancelded Exchanges<img src="/assets/img/full.gif" width="" height="25">

</h4></caption>
									    
									    
										<thead>
											<tr>
											    
											    <th>Username</th>
												<th><?php echo $lang['send']; ?></th>
												<th><?php echo $lang['receive']; ?></th>
												<th><?php echo $lang['amount']; ?></th>
											
												<th><?php echo $lang['status']; ?></th>
												
										<th>Date & Time</th>		
												
												
											</tr>
										</thead>
										<tbody class="tbodybgcolor">
											<?php
											$query = $db->query("SELECT * FROM bit_exchanges ORDER BY id DESC LIMIT 10"); 
											if($query->num_rows>0) {
												while($row = $query->fetch_assoc()) {
													?>
													
													
												<?php
										if($row['status'] == "7") { ?>
													
													
													
													<tr>
													    
													    <td>
															<span class="label label-default"><i class="fa fa-user-o"></i>  <?php echo idinfo($row['uid'],"username"); ?></span>															
														</td>
													    
													    
														<td>
														    
									      
														    
														    <img src="<?php echo gatewayicon(gatewayinfo($row['gateway_send'],"name")); ?>" width="20px" height="20"> <?php echo gatewayinfo($row['gateway_send'],"name"); ?> <?php echo gatewayinfo($row['gateway_send'],"currency"); ?></td>
														<td><img src="<?php echo gatewayicon(gatewayinfo($row['gateway_receive'],"name")); ?>" width="20px" height="20"> <?php echo gatewayinfo($row['gateway_receive'],"name"); ?> <?php echo gatewayinfo($row['gateway_receive'],"currency"); ?></td>
														<td><?php echo $row['amount_send']; ?> <?php echo gatewayinfo($row['gateway_send'],"currency"); ?></td>
												
														<td><?php
										if($row['status'] == "1") {
											echo '<span class="label label-warning"><i class="fa fa-clock-o"></i> '.$lang[status_1].'</span>';
										} elseif($row['status'] == "2") {
											echo '<span class="label label-warning"><i class="fa fa-clock-o"></i> '.$lang[status_2].'</span>';
										} elseif($row['status'] == "3") {
											echo '<span class="label label-info"><i class="fa fa-clock-o"></i> '.$lang[status_3].'</span>';
										} elseif($row['status'] == "4") {
											echo '<span class="label label-success"><i class="fa fa-check"></i> '.$lang[status_4].'</span>';
										} elseif($row['status'] == "5") {
											echo '<span class="label label-danger"><i class="fa fa-times"></i> '.$lang[status_5].'</span>';
										} elseif($row['status'] == "6") {
											echo '<span class="label label-danger"><i class="fa fa-times"></i> '.$lang[status_6].'</span>';
										} elseif($row['status'] == "7") {
											echo '<span class="label label-danger"><i class="fa fa-times"></i> '.$lang[status_7].'</span>';
										} else {
											echo '<span class="label label-default">'.$lang[status_unknown].'</span>';
										}
										?></td>
										
									
										
										
										
										<td>					    
														 	<?php
										if($row['created']) {
											echo ''.date("d/m/Y h:i:sa",$row[created]).'';
										
										    
										} else {
											echo '-';
										}
										?> </td>
										
										
													</tr>
													
																										<?php 	}
											?>


													
													
													<?php
												}
											} else {
												echo '<tr><td colspan="5">'.$lang[still_no_exchanges].'</td></tr>';
											}
											?>

											
										</tbody>
									</table>
								</div>
							</div>
							
							
							
							
							
							
							
							
						</div>
						
						
						
						
						
						
						<!--trending-ads -->		
<div class="section featureds"><div class="btn btn" style="text-align: ; background: #000094; font-size: 17px; color: white; width: 100%; height:40px;"><strong><img src="/assets/img/full.gif" width="" height="30">User Reviews<img src="/assets/img/full.gif" width="" height="30"></strong></div>
							<div class="row">
								<div class="col-sm-12">
								
								</div>
							</div>
							
							<!-- featured-slider -->
							<div class="featured-slider">
								<div id="featured-slider" >
								<?php
							$query = $db->query("SELECT * FROM bit_testimonials WHERE status='1' ORDER BY RAND() LIMIT 5");
							if($query->num_rows>0) {
								while($row = $query->fetch_assoc()) {
								?>
									<!-- featured -->
									<div class="featured">
										<!-- ad-info -->
										<div class="ad-info">
											<?php if($row['type'] == "1") { ?>
											<h3 class="item-price"><span class="label label-success" style="color:#fff;"><i class="fa fa-smile-o"></i> <?php echo $lang['positive']; ?></span></h3>
											<?php } elseif($row['type'] == "2") { ?>
											<h3 class="item-price"><span class="label label-warning" style="color:#fff;"><i class="fa fa-meh-o"></i> <?php echo $lang['neutral']; ?></span></h3>
											
											<?php } elseif($row['type'] == "3") { ?>
											<h3 class="item-price"><span class="label label-danger" style="color:#fff;"><i class="fa fa-frown-o"></i> <?php echo $lang['negative']; ?></span></h3>
											
											<?php } else { ?>
											<h3 class="item-price"><span class="label label-default" style="color:#fff;"><i class="fa fa-meh-o"></i> Unknown</span></h3>
											
											<?php } ?>
											<h4 class="item-title"><?php echo $row['content']; ?></h4>
											<div class="item-cat">
												<span><?php echo idinfo($row['uid'],"username"); ?></span> 
											</div>
										</div><!-- ad-info -->
									</div><!-- featured -->
									<?php
									}
							} else {
								echo $lang['no_have_testimonials'];
							}
							?>
								
									
								</div><!-- featured-slider -->
							</div><!-- #featured-slider -->
						</div><!-- featureds -->
						
					</div>
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					<!-- product-list -->

					<!-- advertisement -->
					<div class="col-md-3">
						
						
						<div class="section" style="background: linear-gradient(#dfffc2, #dfffc2);">
						<div class="section-title tab-manu">
<div class="btn btn" style="text-align: center; background: #000094; font-size: 17px; color: white; width: 100%; height:35px;"><strong><img src="" width="" height="30">Our Reserve Now</strong></div>							</div>
							<br/>
								<div class="row">
								<?php
								$query2 = $db->query("SELECT * FROM bit_gateways ORDER BY id");
								if($query2->num_rows>0) {
									while($row = $query2->fetch_assoc()) {
									?>
									<div class="col-md-12" style="margin-bottom:10px;">
										<img src="<?php echo gatewayicon($row['name']); ?>" width="42px" height="42px" class="img-circle img-bordered pull-left">
										<span class="pull-left" style="margin-left:5px;">
											<span style="font-size:15px;font-weight:bold;"><?php echo $row['name']." ".$row['currency']; ?></span><br/>
											<span class="text text-muted"><?php echo $row['reserve']." ".$row['currency']; ?> </span>
										</span>
									</div>
									<br><br>
									<?php
									}
								} else {
									?>
									<div class="col-md-12">
										<?php echo $lang['no_have_gateways']; ?>
									</div>
									<?php
								}
								?>
								
								</div>
								
								

						</div>
					
					
					<div class="btn btn" style="text-align: center; background: #000094; font-size: 17px; color: white; width: 100%; height:35px;"><strong>Today's Buy-Sell Rate</strong></div>
						<div class="section trending-ads"><strong>




						    
<style>
table, td, th {
    border: 1px solid #ddd;
}
h4 {
    text-align: center;
    }
table {
    border-collapse: collapse;
    width: 100%;
    border: 55x solid #000094;
}
th, td {
    text-align: left;
    padding: 44x;    
}
th {
    background-color: #d9edf7 !important;
    color: #000;
}
</style>

<style>
table, td, th {
    border: 1px solid #ddd;
}
h4 {
    text-align: center;
    }
table {
    border-collapse: collapse;
    width: 108%;
    border: 5px solid #000094;
}
th, td {
    text-align: left;
    padding: 4px;    
}
th {
    background-color: OrangeRed;
    color: #000;
}
</style>

<table>
  <tbody>
  <tr>
    <th><strong>We Accept</strong></th>
    <th><strong>We Buy</strong></th>
    <th><strong>We Sell</strong></th>
    </tr><tr>
    <td>&nbsp; <strong>BITCOIN</strong></td>
    <td><strong>85 Tk</strong></td>
    <td><strong>93 Tk</strong></td>
  </tr>
    <tr>
    <td>&nbsp; <strong>LITECOIN</strong></td>
    <td><strong>86 Tk</strong></td>
    <td><strong>91 Tk</strong></td>
  </tr>
   <tr>
    <td>&nbsp; <strong>Ethereum</strong></td>
    <td><strong>85 Tk</strong></td>
    <td><strong>93 Tk</strong></td>
  </tr>
    <tr>
    <td>&nbsp; <strong>Dogecoin</strong></td>
    <td><strong>85 Tk</strong></td>
    <td><strong>91 Tk</strong></td>
  </tr>
  <tr>
    <td>&nbsp; <strong>PM</strong></td>
    <td><strong>86 Tk</strong></td>
    <td><strong>91 Tk</strong></td>
  </tr>
   <tr>
    <td>&nbsp; <strong> Skrill</strong></td>
   <td><strong>88 Tk</strong></td>
    <td><strong>99 Tk</strong></td>
  </tr>
   <tr>
    <td>&nbsp; <strong>WebMoney</strong></td>
    <td><strong>84 Tk</strong></td>
    <td><strong>91 Tk</strong></td>
  </tr>
  <tr>
    <td>&nbsp; <strong>Netellet</strong></td>
    <td><strong>88  Tk</strong></td>
    <td><strong>99  Tk</strong></td>
  </tr>
  <tr>
    <td>&nbsp; <strong>Payeer</strong></td>
    <td><strong>84 Tk</strong></td>
    <td><strong>95 Tk</strong></td>
  </tr>
  <tr>
      <td>&nbsp; <strong>XRP-XLM</strong></td>
    <td><strong>83 Tk</strong></td>
    <td><strong>91 Tk</strong></td>
  </tr>
  <tr>
      <td>&nbsp; <strong>Payoneer</strong></td>
    <td><strong>82 Tk</strong></td>
    <td><strong>91 Tk</strong></td>
  </tr>
  <tr>
      <td>&nbsp; <strong>Paypal</strong></td>
    <td><strong>70 Tk</strong></td>
    <td><strong>00 TK </strong></td>
  </tr>
  <tr>
      <td>&nbsp; <strong>STEEM</strong></td>
    <td><strong>10 Tk</strong></td>
    <td><strong>15 Tk</strong></td>
  </tr>
  <tr>
</tr></tbody></table>
<h4></h4> <strong></strong><img src="/assets/img/star.gif" height="40px">

</strong>
 </div>
 
 
 <div class="section">
							<div class="section-title tab-manu">
								<h4><?php echo $lang['track_exchange']; ?></h4>
							</div>
							<br/>
							<form action="<?php echo $settings['url']; ?>track" method="POST">
								<div class="form-group">
									<input type="text" class="form-control" name="order_id" placeholder="<?php echo $lang['type_here_exchange_id']; ?>">
								</div>
								<button type="submit" style="background: #000094;" class="btn btn-primary btn-block" name="bit_track"><?php echo $lang['btn_track']; ?></button>
							</form>
						</div>
						
						
						
						
						
						
						
						
						<div class="btn btn" style="text-align: center; background: #000094; font-size: 18px; color: white; width: 100%; height:40px;"><img src="/assets/img/full.gif" width="" height="25"><strong>Latest Update</strong><img src="/assets/img/full.gif" width="" height="25"></div>
						<div style=" background-color: #fff;color:#1b1e21;border-color: #c6c8ca;">
<marquee style="padding-left:4px;margin-left: 15px" onmouseout="this.start()" onmouseover="this.stop()" direction="up" scrollamount="2" behavior="scroll" height="300">
    
 <span style="color:green;"><strong>সকল ইউজারদের অনুরোধ করা হল- আপনারা লেনদেন করার আগে অবশ্যই সাইটের সকল নিয়ম ভালোভাবে পড়ে নিবেন ।</strong></span>
<br>
<hr><span style="color:red;"><strong>লেনদেন করার আগে অবশ্যই সাইটের রিজার্ভ দেখে নিবেন ।</strong></span>
<br>
<hr><span style="color:green;"><strong>যারা Skrill/Neteller BUY-Sell করেন তাদের বলা হচ্ছে মিনিমাম 10 $  Order করবেন । তবে , 30$ এর নিচে অর্ডার করলে ফি বাবদ 60 টাকা Extra দিতে হবে। </strong></span>
<br>
<hr><span style="color:red;"><strong>ADMIN অনলাইনে না থাকলে ORDER করতে পারবেন এবং ডলার অথবা পেমেন্ট আমাদের সার্ভিস টাইম এর মধ্যে না পেলে আমাদের সাথে যোগাযোগ করেবেন ।</strong></span>
<br>
<hr><span style="color:green;"><strong>আমরা আমাদের jShare.Ga ওয়েব সাইট ব্যতীত অন্য কোন মাধ্যমে লেনদেন করিনা।</strong></span>
<br>
<hr><span style="color:red;"><strong>আমাদের সার্ভিস ভালো লাগলে অবশ্যই একটি Testimonials দিয়ে যাবেন । </strong></span>
<br>
<hr><span style="color:green;"><strong>  - ধন্যবাদ ।। </strong></span>
<br>
<hr></marquee>

</div>
						
						
						
						
 
					</div><!-- advertisement -->
				</div><!-- row -->
				
				
				
				
				
				
				<div class="btn btn" style="text-align: center; background: #000094; font-size: 18px; color: white; width: 100%; height:40px;"><img src="/assets/img/full.gif" width="" height="25"><strong>We Accept</strong><img src="/assets/img/full.gif" width="" height="25"></div>
				
				
				
				
				
				
				
				
				
				
				
				<div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
                <div id="Carousel" class="carousel slide">
                 
              
              
              
              <script>
$(document).ready(function() {
    $('#Carousel').carousel({
        interval: 3000
    })
});
</script>
              
              
            
                 
              <div class="row">
  <div class="col-md-12 col-sm-12 col-xs-12">
                <div id="Carousel" class="carousel slide">
                 
              
                 
                <!-- Carousel items -->
                <div class="carousel-inner">
                    
                <div class="item">
                 <div class="row">
                     
                     
                										
									
									<div class="col-md-2 col-xs-4"><a href="#" class="thumbnail"><img src="/uploads/1597513127_icon.png" alt="Skrill.png" style="height:80px;"></a></div>
									
									
									
									
																				
									
									<div class="col-md-2 col-xs-4"><a href="#" class="thumbnail"><img src="/uploads/1597512981_icon.png" alt="Skrill.png" style="height:80px;"></a></div>
									
									
									
									
																				
									
									<div class="col-md-2 col-xs-4"><a href="#" class="thumbnail"><img src="/uploads/1597512826_icon.png" alt="Skrill.png" style="height:80px;"></a></div>
									
									
									
									
																				
									
									<div class="col-md-2 col-xs-4"><a href="#" class="thumbnail"><img src="/uploads/1597512723_icon.png" alt="Skrill.png" style="height:80px;"></a></div>
									
									
									
									
																				
									
									<div class="col-md-2 col-xs-4"><a href="#" class="thumbnail"><img src="/uploads/1597512610_icon.png" alt="Skrill.png" style="height:80px;"></a></div>
									
									
									
									
																				
									
									<div class="col-md-2 col-xs-4"><a href="#" class="thumbnail"><img src="/uploads/1597512465_icon.png" alt="Skrill.png" style="height:80px;"></a></div>
									
									
									
									
											                   
                
                 </div><!--.row-->
                </div><!--.item-->
                 
                <div class="item active">
                 <div class="row">
                   										
									
									<div class="col-md-2 col-xs-4"><a href="#" class="thumbnail"><img src="/uploads/1597510146_icon.png" alt="Skrill.png" style="height:80px;"></a></div>
									
									
									
									
																				
									
									<div class="col-md-2 col-xs-4"><a href="#" class="thumbnail"><img src="/uploads/1597510350_icon.jpg" alt="Skrill.png" style="height:80px;"></a></div>
									
									
									
									
																				
									
									<div class="col-md-2 col-xs-4"><a href="#" class="thumbnail"><img src="/uploads/1597510528_icon.png" alt="Skrill.png" style="height:80px;"></a></div>
									
									
									
									
																				
									
									<div class="col-md-2 col-xs-4"><a href="#" class="thumbnail"><img src="/uploads/1597511168_icon.png" alt="Skrill.png" style="height:80px;"></a></div>
									
									
									
									
																				
									
									<div class="col-md-2 col-xs-4"><a href="#" class="thumbnail"><img src="/uploads/1597511376_icon.png" alt="Skrill.png" style="height:80px;"></a></div>
									
									
									
									
																				
									
									<div class="col-md-2 col-xs-4"><a href="#" class="thumbnail"><img src="/uploads/1597511540_icon.png" alt="Skrill.png" style="height:80px;"></a></div>
									
									
									
									
											                  
                 </div><!--.row-->
                </div><!--.item-->
                 
                
                 </div>
                </div>

                                           

                 
  </div>
 </div>
		
		
		
		
		
	
		
		
		
		<!-- container -->
		
		<div class="btn btn" style="text-align: center; background: #000094; font-size: 18px; color: white; width: 100%; height:40px;"><img src="/assets/img/full.gif" width="" height="25"><strong>Exchangers-Status</strong><img src="/assets/img/full.gif" width="" height="25"></div>
		
		
		
		
		
		
		
		
		<div class="row" style="background:#bdbdbd; padding: 15px; margin: px 0 10px 0; border-radius: 7px;color:white;">
	<div class="col-lg-3">
		<div class="btn btn" style="text-align: center; background: #26A69A; font-size: 17px; color: white; width: 100%; height:110px;" div="">
                    <div class="panel-body fa-icons">
                        <big class="social-title">TOTAL MEMBER'S</big>
                        <h3 class="count"><?php $query = $db->query("SELECT * FROM bit_users"); echo $query->num_rows; ?></h3>
                          
                    </div>
                </div>
	</div>
	<div class="col-lg-3">
		<div class="btn btn" style="text-align: center; background: #AB47BC; font-size: 17px; color: white; width: 100%; height:110px;" div="">
                    <div class="panel-body fa-icons">
                        <big class="social-title">TOTAL EXCHANGE</big>
                        <h3 class="count"><?php $query = $db->query("SELECT * FROM bit_exchanges"); echo $query->num_rows; ?></h3>
                            
                    </div>
                </div>



</div>
	<div class="col-lg-3">
		<div class="btn btn" style="text-align: center; background: #bd1368; font-size: 17px; color: white; width: 100%; height:110px;" div="">
                    <div class="panel-body fa-icons">
                        <big class="social-title">TESTIMONIALS</big>
                        <h3 class="count"><?php $query = $db->query("SELECT * FROM bit_testimonials"); echo $query->num_rows; ?></h3>
                          
                    </div>
                </div>
	
	
</div>
	<div class="col-lg-3">
		<div class="btn btn" style="text-align: center; background: #005bd1; font-size: 17px; color: white; width: 100%; height:110px;" div="">
                    <div class="panel-body fa-icons">
                        <big class="social-title">WITHDRAWALS</big>
                         <h3 class="count"><?php $query = $db->query("SELECT * FROM bit_users_withdrawals"); echo $query->num_rows; ?>
                            </h3>
                    </div>
                </div>
			
			
			
			
		</div><!-- container -->
		
		
	</div>

		
		
		
	
	</div></div></div>
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
			</div><!-- main-content -->
		</div><!-- container -->
	
	
	
	</section><!-- main -->
	<div class="row" style="background:#91c402; padding: 15px; margin: px 0 10px 0; border-radius: 7px;">
		<div class="col-md-3 text-center">
						<h2>Very Fast</h2>
			<h3><i class="fa fa-users" aria-hidden="true"></i> Clients Payment</h3>
		</div>
		<div class="col-md-3 text-center">
						<h2>Best</h2>			
			<h3><i class="fa fa-exchange" aria-hidden="true"></i> Exchanges Rate</h3>
		</div>		
		<div class="col-md-3 text-center">
						<h2>Manualy</h2>			
			<h3><i class="fa fa-refresh" aria-hidden="true"></i> Exchanges System</h3>
		</div>
		<div class="col-md-3 text-center">
			<h2>
				BDT USD			</h2>			
			<h3><i class="fa fa-money" aria-hidden="true"></i> Exchange Currency</h3>
		</div>
	</div>
	
	
	
