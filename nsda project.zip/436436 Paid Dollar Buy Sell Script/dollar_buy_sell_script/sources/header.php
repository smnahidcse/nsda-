<!DOCTYPE html>
<html lang="en">
  <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="doridrotech.com">
   	<meta name="description" content="<?php echo $settings['description']; ?>">
	<meta name="keywords" content="<?php echo $settings['keywords']; ?>">

    <title><?php echo BitDecodeTitle($_GET['a']); ?></title>

   <!-- CSS -->
    <link rel="stylesheet" href="<?php echo $settings['url']; ?>assets/css/bootstrap.min.css" >
    <link rel="stylesheet" href="<?php echo $settings['url']; ?>assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo $settings['url']; ?>assets/css/icofont.css">
    <link rel="stylesheet" href="<?php echo $settings['url']; ?>assets/css/owl.carousel.css">  
    <link rel="stylesheet" href="<?php echo $settings['url']; ?>assets/css/slidr.css">     
    <link rel="stylesheet" href="<?php echo $settings['url']; ?>assets/css/main.css">  
	<link id="preset" rel="stylesheet" href="<?php echo $settings['url']; ?>assets/css/presets/preset2.css">	
    <link rel="stylesheet" href="<?php echo $settings['url']; ?>assets/css/responsive.css">
		<?php if($lang['lang_type'] == "rtl") { ?>
	<link href="<?php echo $settings['url']; ?>assets/css/bootstrap-flipped.min.css" rel="stylesheet" type="text/css" media="all" />
	<link href="<?php echo $settings['url']; ?>assets/css/bootstrap-rtl.min.css" rel="stylesheet" type="text/css" media="all" />
	<?php } ?>
	<!-- font -->
	<link href='https://fonts.googleapis.com/css?family=Ubuntu:400,500,700,300' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Signika+Negative:400,300,600,700' rel='stylesheet' type='text/css'>
	
	<link rel="icon" href="<?php echo $settings['url']; ?>assets/imgs/favicon.ico" type="image/x-icon">

	<script src="<?php echo $settings['url']; ?>assets/js/jquery.min.js"></script>
    <script src="<?php echo $settings['url']; ?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo $settings['url']; ?>assets/js/BitExchanger.js"></script>
  </head>
  <body>
	<!-- header -->
	
	
	
	
	
	
	
	<header id="header" class="clearfix">
		<!-- navbar -->
		<nav class="navbar navbar-default" style="">
			<div class="container">
				<!-- navbar-header -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo $settings['url']; ?>"><img style="
    height: 90px;
    width: 175px;
" class="img-responsive" src="<?php echo $settings['url']; ?>assets/img/logo.png" alt="Logo"></a>
				</div>
				<!-- /navbar-header -->
				
				<div class="navbar-left">
					<div class="collapse navbar-collapse" id="navbar-collapse">
						<ul class="nav navbar-nav">
							<li><a href="<?php echo $settings['url']; ?>"><form>
<input style="width: 127px; padding:10px; cursor: pointer; 
box-shadow: 1px 1px 1px; #999; -webkit-box-shadow: 1px 1px 1px #999; -moz-box-shadow: 1px 1px 1px #999; font-weight: bold; 
background:#000094; color: white; border-radius: 8px; border: 5px solid white; font-size:17px;" value="BUY-SELL " type="button">
</form></a></li>
							<li><a href="<?php echo $settings['url']; ?>testimonials"> <form>
<input style="width: 160px; padding:10px; cursor: pointer; 
box-shadow: 1px 1px 1px; #999; -webkit-box-shadow: 1px 1px 1px #999; -moz-box-shadow: 1px 1px 1px #999; font-weight: bold; 
background:#000094; color: white; border-radius: 8px; border: 5px solid white; font-size:17px;" value="TESTIMONIALS" type="button">
</form></a></li>
							<li><a href="<?php echo $settings['url']; ?>affiliate"><form>
<input style="width: 160px; padding:10px; cursor: pointer; 
box-shadow: 1px 1px 1px; #999; -webkit-box-shadow: 1px 1px 1px #999; -moz-box-shadow: 1px 1px 1px #999; font-weight: bold; 
background:#000094; color: white; border-radius: 8px; border: 5px solid white; font-size:17px;" value="AFFILIATE" type="button">
</form></a></li>
							<li><a href="<?php echo $settings['url']; ?>contact"><form>
<input style="width: 150px; padding:10px; cursor: pointer; 
box-shadow: 1px 1px 1px; #999; -webkit-box-shadow: 1px 1px 1px #999; -moz-box-shadow: 1px 1px 1px #999; font-weight: bold; 
background:#000094; color: white; border-radius: 8px; border: 5px solid white; font-size:17px;" value="CONTACT" type="button">
</form></a></li>
						</ul>
					</div>
				</div>
				
				<!-- nav-right -->
				<div class="nav-right">
					<!-- language-dropdown -->

				



	<!-- sign-in -->					
					<ul class="sign-in">
						<li><i class="fa fa-user"></i></li>
							<?php if(checkSession()) { ?>
						<li><a href="<?php echo $settings['url']; ?>account/exchanges"><?php echo idinfo($_SESSION['bit_uid'],"username"); ?></a></li>
						<li><a href="<?php echo $settings['url']; ?>logout"><?php echo $lang['logout']; ?></a></li>
						<?php } else { ?>
						<li><a href="<?php echo $settings['url']; ?>login"><?php echo $lang['login']; ?></a></li>
						<li><a href="<?php echo $settings['url']; ?>register"><?php echo $lang['create_account']; ?></a></li>
						<?php } ?>
					</ul><!-- sign-in -->




					
		
								</br >
								
							<img src="<?php echo $settings['url']; ?>assets/icons/operator.png" width="30" height="30"> <span class="label label-success"> <?php echo $lang['operator']; ?>: <?php if($settings['operator_status'] == "1") { echo '<span class="text text-success">'.$lang[operator_online].'</span>'; } else { echo '<span class="text text-danger">'.$lang[operator_offline].'</span>'; } ?></span>  <img src="/assets/img/on.gif" width="25" height="25">
							<br>

<span class="label label-success" style="background-color:#5cb85c;">Work time: 09:00 AM - 11:00 PM
</span>

 </div>
 <!-- nav-right -->
 </div><!-- container -->

 </nav><!-- navbar -->
 </header>
<span class="btn btn" style="text-align: center; font-weight: 600; font-size: 18px; background: #000094; color: white; width: 100%; height:40px;">
<marquee behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();" id="MARQUEE1" style="text-align: left;" class="scrolling">  
<span style="color: yellow"><strong>NEW UPDATE:</strong></span>
নোটিশ &lt;=GotUsd All User কে স্বাগতম।যে কোন প্রয়োজনে আমাদের কল দিতে পারেন Support Number 880180000000  What's App &amp; Imo  / Skrill &amp; Neteller এর জন্য Extra Fee +60  টাকা দিতে হবে।  আর  অন্যান্য ডলারের রেট যা সেই টাকা দিলেই সমপরিমান টাকার ডলার পাবেন।</marquee></span>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
